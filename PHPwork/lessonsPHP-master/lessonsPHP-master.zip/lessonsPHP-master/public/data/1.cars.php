<?php
/**
 * Created by PhpStorm.
 * User: Алексей
 * Date: 20.12.2018
 * Time: 21:13
 */

$cars = [];