<?php
/**
 * Created by PhpStorm.
 * User: Алексей
 * Date: 12.01.2019
 * Time: 12:26
 */
?>

<div>
    <span><?php echo $this->name; ?></span>
    <span><?php echo $this->cost; ?></span>
</div>
