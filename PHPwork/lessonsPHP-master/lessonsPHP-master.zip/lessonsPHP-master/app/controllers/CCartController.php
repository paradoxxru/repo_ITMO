<?php
/**
 * Created by PhpStorm.
 * User: Алексей
 * Date: 17.01.2019
 * Time: 21:51
 */
require_once ("../app/controllers/IPageController.php");
class CCartController implements IPageController
{
    public function setPermissions($permissions)
    {
        // TODO: Implement setPermissions() method.
    }

    public function render()
    {
        // TODO: Implement render() method.
    }

}