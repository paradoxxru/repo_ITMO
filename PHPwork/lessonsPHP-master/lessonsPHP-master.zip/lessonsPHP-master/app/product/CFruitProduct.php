<?php

/**
 * Created by PhpStorm.
 * User: User
 * Date: 18.01.2019
 * Time: 20:08
 */
require_once ("../app/product/CProduct.php");
class CFruitProduct extends CProduct
{

}